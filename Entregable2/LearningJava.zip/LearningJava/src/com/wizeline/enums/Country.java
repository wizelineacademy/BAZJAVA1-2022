package com.wizeline.enums;

public enum Country {
    US, MX, FR
}
