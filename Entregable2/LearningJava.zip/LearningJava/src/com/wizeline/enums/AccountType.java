package com.wizeline.enums;

public enum AccountType {
    NOMINA, AHORRO, PLATINUM
}
