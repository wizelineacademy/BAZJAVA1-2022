package factorymethod.notifications;

public interface Notification {
    void notifyUser();
}
