package com.wizeline.cursojava.serviceTest;

import com.wizeline.cursojava.daoTest.UserDAO;
import com.wizeline.cursojava.model.User;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;

import com.wizeline.cursojava.dto.ResponseDTO;
import com.wizeline.cursojava.dto.UserDTO;
import com.wizeline.cursojava.service.UserService;

@WebMvcTest(UserServiceTest.class)
public class UserServiceTest {
	
	private static final Logger log = LoggerFactory.getLogger(UserServiceTest.class);

	@MockBean
	private UserService service;

	@MockBean
	private UserDAO userDAO;
	
	@Test
	@DisplayName("Creacion de usuario - Test")
	public void dadoDatosDeUsuarioEsperamosCrearUnUsuario() {
		log.info("Test para creacion de usuario");
		UserDTO esperado = new UserDTO();
		esperado.setId(1);
		esperado.setName("name");
		esperado.setUserName("userName");
		esperado.setEmail("mail");

		ResponseDTO responseDTO = new ResponseDTO();
		responseDTO.setCode("OK000");
		responseDTO.setStatus("Usuario Creado");

		Mockito.when(service.saveUser(Mockito.any(UserDTO.class))).thenReturn(ResponseEntity.ok(responseDTO));

		ResponseEntity<ResponseDTO> respuesta = service.saveUser(esperado);

		Assertions.assertAll(
				() -> Assertions.assertEquals("OK000", respuesta.getBody().getCode()),
				() -> Assertions.assertNotNull(respuesta));
		log.info("Estatus del la creacion de usuario" + respuesta.getBody().getStatus());
	}
	@Test
	@DisplayName("Edge Case - CreateUserService - CuerpoEntradaNulo")
	public void DadoElServicioCrearUsuario_CuandoSePasaElCampoNulo_DeberiaTronarConNullPointerException() {
		log.info("Se mockea el servicio que devolvera la respuesta mala esperada");
		Mockito.when(service.saveUser(Mockito.any())).thenThrow(new NullPointerException("Campo de entrada nulo"));

		log.info("Al intentar consumir el servicio, tratamos de esperar una excepcion");
		NullPointerException thrown = Assertions.assertThrows(
				NullPointerException.class,
				() -> service.saveUser(new UserDTO()),
				"Campo de entrada nulo"
		);

		log.info("Se compara el resultado esperado con el devuelto");
		Assertions.assertEquals("Campo de entrada nulo", thrown.getMessage());
	}

	@Test
	@DisplayName("Busqueda usuario por ID - Test")
	public void dadoUnId_ServicioBusquedaPorId_RespondeConDatosDeUsuario() {
		Integer id = 1;

		User user = new User();
		user.setId(1);
		user.setName("Edson");
		user.setUserName("Garcia");
		user.setEmail("mail@ejemplo.com");
		log.info("Se obtienen los valores de retorno");
		Mockito.when(userDAO.findById(Mockito.anyInt())).thenReturn(user);

		log.info("Creacion de respuesta esperada");
		ResponseDTO responseDTO = new ResponseDTO();
		responseDTO.setCode("OK000");
		responseDTO.setStatus("Usuario encontrado");
		responseDTO.setResultado(userDAO.findById(id));

		log.info("Se mockea el servicio que respondera de manera exitosa");
		Mockito.when(service.findById(Mockito.anyInt())).thenReturn(ResponseEntity.ok(responseDTO));

		log.info("Se consume el servicio mockeado");
		ResponseEntity<ResponseDTO> respuesta = service.findById(id);
		log.info("Se compara la respuesta esperada con la obtenida");
		Assertions.assertAll(
				() -> Assertions.assertEquals("OK000", respuesta.getBody().getCode()),
				() -> Assertions.assertEquals("Usuario encontrado", respuesta.getBody().getStatus())
		);
	}
	@Test
	@DisplayName("Edge Case - ObtenerUsuarioPorIdUserService - ValidaParametroNulo&Vacio")
	public void DadoElServicioObtenerusuarioPorId_CuandoSeIngresaUnIdUsuarioNulo_DebeTronarConNullpointerException(){
		log.info("Se mockea el servicio que puede recibir valor null o un string vacio");
		Mockito.when(service.findById(Mockito.isNull())).thenThrow(new NullPointerException("El campo: idUsuario no debe ser nulo"));
		Mockito.when(service.findById(Mockito.anyInt())).thenThrow(new NullPointerException("El campo: idUsuario no debe estar vacio"));

		Integer id = null;

		log.info("Se consume el servicio mockeado para obtener la excepcion esperada");
		NullPointerException respuestaAssertOptional = id == null ? Assertions.assertThrows(
				NullPointerException.class,
				() -> service.findById(Integer.valueOf("")),
				"El campo: idUsuario no debe estar vacio"
		) : Assertions.assertThrows(
				NullPointerException.class,
				() -> service.findById(null),
				"Parametro de entrada: idUsuario no debe ser nulo"
		);
		log.info("SE compara el resultado obtenido con el esperado");
		Assertions.assertEquals("El campo: idUsuario no debe estar vacio", respuestaAssertOptional.getMessage());
	}

	@Test
	@DisplayName("Elimina usuario por ID - Test")
	public void dadoUnId_ServicioEliminarPorId_RespondeConUnOKEnController() {
		Integer id = 1;

		log.info("Se mockea el componente que regresa la respuesta esperada");
		Mockito.when(userDAO.deleteUser(Mockito.anyInt())).thenReturn(1L);

		log.info("Creacion de respuesta esperada");
		ResponseDTO responseDTO = new ResponseDTO();
		responseDTO.setCode("OK000");
		responseDTO.setStatus("Usuario eliminado");
		responseDTO.setResultado(userDAO.deleteUser(id));

		log.info("Se mockea el servicio que responde con la respuesta general esperada");
		Mockito.when(service.deleteUser(Mockito.anyInt())).thenReturn(ResponseEntity.ok(responseDTO));

		log.info("Consumo de servicio mockeado ");
		ResponseEntity<ResponseDTO> respuesta = service.deleteUser(id);
		log.info("Se compara el resultado con la respuesta esperada");
		Assertions.assertAll(
				() -> Assertions.assertEquals("OK000", respuesta.getBody().getCode()),
				() -> Assertions.assertEquals("Usuario eliminado", respuesta.getBody().getStatus())
		);
	}
	@Test
	@DisplayName("Edge Case - EliminacionDeUsuarioPorIdUserService - ValidaParametroNulo&Vacio")
	public void DadoElServicioEliminarusuarioPorId_CuandoSeIngresaUnIdDeUsuarioNuloOVacio_DeberiaTronarConNullPointerException(){
		log.info("Se mockea el servicio que puede recibir un campo ya sea null o String vacio y regresa una excepcion esperada");
		Mockito.when(service.deleteUser(Mockito.isNull())).thenThrow(new NullPointerException("El campo: idUsuario no debe ser nulo"));
		Mockito.when(service.findById(Mockito.anyInt())).thenThrow(new NullPointerException("El campo: idUsuario no debe estar vacio"));

		Integer id = null;

		log.info("Consumo del servicio mockeado");
		NullPointerException respuestaAssertOptional = id == null ? Assertions.assertThrows(
				NullPointerException.class,
				() -> service.findById(Integer.valueOf("")),
				"El campo: id no debe estar vacio"
		) : Assertions.assertThrows(
				NullPointerException.class,
				() -> service.findById(null),
				"Parametro de entrada: id no debe ser nulo"
		);
		log.info("Se compara el resultado con la respuesta esperada");
		Assertions.assertEquals("El campo: idUsuario no debe estar vacio", respuestaAssertOptional.getMessage());
	}

	@Test
	@DisplayName("Actualizacion de datos de usuario - Test")
	public void dadoUnId_ServicioActualizarPorId_RespondeConDatosDeUsuarioActualizado() {
		Integer id = 1;

		User user = new User();
		user.setId(1);
		user.setName("Edson");
		user.setUserName("Garcia");
		user.setEmail("mail@ejemplo.com");

		UserDTO userDto = new UserDTO();
		userDto.setId(1);
		userDto.setName("ALfredo");
		userDto.setUserName("Garcia");
		userDto.setEmail("mail@ejemplo1.com");

		Mockito.when(userDAO.updateUser(id, userDto)).thenReturn(user);

		log.info("Se crea la respuesta general con sus datos esperados");
		ResponseDTO responseDTO = new ResponseDTO();
		responseDTO.setCode("OK000");
		responseDTO.setStatus("Datos actualizados");
		responseDTO.setResultado(userDAO.updateUser(id,userDto));

		log.info("Se mockea el srevicio que regresara la respuesta general correcta esperada");
		Mockito.when(service.updateUser(id, userDto)).thenReturn(ResponseEntity.ok(responseDTO));

		log.info("Consumo de servicio mockeado con anterioridad");
		ResponseEntity<ResponseDTO> resultado = service.updateUser(id, userDto);

		log.info("Se compara la respuesta recibida con la esperada");
		Assertions.assertAll(
				() -> Assertions.assertEquals("OK000", resultado.getBody().getCode()),
				() -> Assertions.assertEquals("Contrasenia actualizada!", resultado.getBody().getStatus())
		);
	}
	@Test
	@DisplayName("Edge Case - ActualizaDatosDeUsuarioService - ParametrosDeEntradaNulos")
	public void DadoElServicioActulizaUsuario_CuandoNoSeIngresanLosParametros_DeberiaTronarConNullPointerException() {
		log.info("Se mockea el servicio que se espera responder con un nullpointerException");
		Mockito.when(service.updateUser(Mockito.isNull(), Mockito.isNull())).thenThrow(new NullPointerException("Parametros de entrada nulos"));

		log.info("Se intenta consumir el servicio que debería regresar la excepcion esperada");
		NullPointerException thrown = Assertions.assertThrows(
				NullPointerException.class,
				() -> service.updateUser(null, null),
				"Parametros de entrada nulos"
		);

		log.info("Se compara el resultado con la respuesta esperada");
		Assertions.assertEquals("Parametros de entrada nulos", thrown.getMessage());
	}

	@Test
	@DisplayName("Consume api publica - Test Service")
	public void DadoElServicioConsumirApiPublica_CuandoSeMandaALlamar_SeConsumeYRegresaLaRespuesta(){
		/* Pruebas para Happy Path - UserServiceTest - ConsumeApiPublicaService */
		log.info("Se inicializa el campo url esperado");
		String url = "hhtp:ejemploxd";

		log.info("Creamos la respuesta esperada");
		ResponseDTO responseDTO = new ResponseDTO();
		responseDTO.setCode("OK000");
		responseDTO.setStatus("Api Consumida");

		log.info("Se mockea el servicio que devolvera la respuesta general esperada");
		Mockito.when(service.getUserApiPublica(Mockito.anyString())).thenReturn(ResponseEntity.ok(responseDTO));

		log.info("Consumo de srevicio mockeado con anterioridad");
		ResponseEntity<ResponseDTO> respuesta = service.getUserApiPublica(url);

		log.info("Comparamos los resultados obtenidos con los resultados esperados");
		Assertions.assertAll(
				() -> Assertions.assertEquals("OK000", respuesta.getBody().getCode()),
				() -> Assertions.assertEquals("Api Consumida", respuesta.getBody().getStatus())
		);
	}

	@Test
	@DisplayName("Edge Case - ConsumeApiPublica - ValidaParametroUrlNulo&Vacio")
	public void DadoElServicioConsumeApiPublica_CuandoSeIngresaElCampoUrlNuloOVacio_DeberiaTronarConNullPointerException(){
		log.info("Se mockea el servicio que puede aceptar valor nulo o String vacio");
		Mockito.when(service.getUserApiPublica(Mockito.isNull())).thenThrow(new NullPointerException("El campo: url no debe ser nulo"));
		Mockito.when(service.getUserApiPublica(Mockito.anyString())).thenThrow(new NullPointerException("El campo: url no debe estar vacio"));

		String url = null;

		log.info("Consumo de servicio mockeado y esperamos la excepcion esperada");
		NullPointerException respuestaAssertOptional = url == "" ? Assertions.assertThrows(
				NullPointerException.class,
				() -> service.getUserApiPublica(""),
				"El campo: url no debe estar vacio"
		) : Assertions.assertThrows(
				NullPointerException.class,
				() -> service.getUserApiPublica(null),
				"El campo: url no debe ser nulo"
		);

		log.info("Se compara el resultado con la respuesta esperada");
		Assertions.assertEquals("El campo: url no debe ser nulo", respuestaAssertOptional.getMessage());
	}

}
