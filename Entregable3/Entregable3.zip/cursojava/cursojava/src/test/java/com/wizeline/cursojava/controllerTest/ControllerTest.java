package com.wizeline.cursojava.controllerTest;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.wizeline.cursojava.controllers.UserController;
import com.wizeline.cursojava.daoTest.UserDAO;
import com.wizeline.cursojava.dto.ErrorDTO;
import com.wizeline.cursojava.dto.ResponseDTO;
import com.wizeline.cursojava.dto.UserDTO;
import com.wizeline.cursojava.model.User;
import com.wizeline.cursojava.service.UserService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.util.LinkedMultiValueMap;

import java.util.ArrayList;
import java.util.List;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(UserController.class)
public class ControllerTest {
    private static final Logger log = LoggerFactory.getLogger(ControllerTest.class);

    @MockBean
    private UserService userService;

    @MockBean
    private UserDAO userDAO;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private MockMvc mockMvc;

    @Test
    @DisplayName("Crear Usuario")
    public void DadoElServicioCrearUsuario_CuandoTieneValoresAceptables_RegresaStatus200() throws Exception {
        /* Pruebas para Happy Path - UserSControllerTest - CreateUserController */
        log.info("Se crea el cuerpo que viajará por la petición de prueba, con nombreDeUsuario y contrasenia");
        UserDTO usuarioDTO2 = new UserDTO();
        usuarioDTO2.setId(1);
        usuarioDTO2.setName("name");
        usuarioDTO2.setUserName("userName");
        usuarioDTO2.setEmail("mail");

        log.info("Se crea un objeto que debe regresar la capa dao");
        User usuarioEntidad = new User();

        log.info("Se copian los valores que contiene el cuerpo original al cuerpo esperado");
        BeanUtils.copyProperties(usuarioDTO2, usuarioEntidad);

        log.info("Se mockea la capa dao para cuando se mande a llamar este con un cuerpo de cierto tipo, responda con la respuesta esperada");
        Mockito.when(userDAO.saveUser(Mockito.any(User.class))).thenReturn(usuarioEntidad);

        log.info("Se arma la respuesta esperada del servicio cargandole todos los parametros esperados");
        ResponseDTO dto = new ResponseDTO();
        dto.setCode("OK000");
        dto.setStatus("Usuario creado");
        dto.setResultado(userDAO.saveUser(usuarioEntidad));

        log.info("Se mockea el servicio para devolver la respuesta esperada, en este caso un exito");
        Mockito.when(userService.saveUser(Mockito.any(UserDTO.class))).thenReturn(ResponseEntity.ok(dto));

        log.info("Se arma la peticion como si fuera un postman con la ruta y el cuerpo de entrada");
        MvcResult result = mockMvc.perform(post("/api/v1/users/saveUser")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(usuarioDTO2))
                )
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value("OK000"))
                .andExpect(jsonPath("$.status").value("Usuario creado"))
                .andExpect(content().json(objectMapper.writeValueAsString(dto)))
                .andReturn();

        log.info("MvcResult cuerpo de respuesta: " + result.getResponse().getContentAsString());
    }

    @Test
    @DisplayName("Edge Case - CrearUsuarioController - ValidaRequestBodyNulo")
    public void DadoElServicioCrearUsuario_CuandoTieneBodyNulo_RegresaRespuestaGeneralErroneaControlada() throws Exception {
        log.info("Instanciamos serializador de objetos");
        Gson gson = new Gson();

        log.info("serializamos un cuerpo nulo para la simulacion");
        String json = gson.toJson(null);

        log.info("Se arma la peticion como si fuera un postman con la ruta y el cuerpo de entrada, todo con el resultado esperado");
        MvcResult result = mockMvc.perform(post("/api/v1/users/getAllUsers")
                        .content(json))
                .andExpect(status().isBadRequest())
                .andReturn();

        log.info("Valor peticion: "+result.getResponse().getErrorMessage());
    }


    @Test
    @DisplayName("Obtener Usuarios")
    public void DadoElServicioObtenerUsuarios_CuandoEsLlamado_DevuelveListaDeUsuariosExistentes() throws Exception {
        /* Pruebas para Happy Path*/
        log.info("Se inicializa y cargan valores de la lista esperada por la api");
        List<User> usuariosEntidad = new ArrayList<>();
        User user = new User();
        user.setId(1);
        user.setName("Edson");
        user.setUserName("Garcia");
        user.setEmail("mail@ejemplo.com");
        usuariosEntidad.add(user);

        log.info("Se mockea el componente que responderá la lista anterior");
        Mockito.when(userDAO.getUsers()).thenReturn(usuariosEntidad);

        log.info("Se crea la respuesta general esperada, asi como sus valores correspondientes");
        ResponseDTO dto = new ResponseDTO();
        dto.setCode("OK000");
        dto.setStatus("Usuario encontrado");
        dto.setResultado(userDAO.getUsers());

        log.info("Se mockea el servicio que respondera con la respuesta general esperada");
        Mockito.when(userService.getUsers()).thenReturn(ResponseEntity.ok(dto));

        log.info("Se arma la peticion como si fuera un postman con la ruta, todo con el resultado esperado");
        MvcResult result = mockMvc.perform(get("/api/v1/users/getAllUsers"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value("OK000"))
                .andExpect(jsonPath("$.status").value("Usuario encontrado"))
                .andExpect(content().json(objectMapper.writeValueAsString(dto)))
                .andReturn();
        log.info("Resultado obtenerUsuarios: " + result.getResponse().getContentAsString());
    }

    @Test
    @DisplayName("Edge Case - ObtenerUsuariosController - RespuestaErroneaControlada")
    public void DadoElServicioObtenerUsuarios_CuandoEsLlamadoYNoExistenUsuarios_DevuelveUnErrorGeneralControlado() throws Exception {
        log.info("Se estructura la respuesta general mala esperada con sus respectivos valores");
        ErrorDTO errorDTO = new ErrorDTO("ER001", "No se encontraron usuarios");

        ResponseDTO dto = new ResponseDTO();
        dto.setCode("ER001");
        dto.setStatus("No se encontraron usuarios");
        dto.setErrors(errorDTO);

        log.info("Se mockea el servicio que devolvera la respuesta general mala esperada");
        Mockito.when(userService.getUsers()).thenReturn(new ResponseEntity<>(dto, HttpStatus.BAD_REQUEST));

        log.info("Se arma la peticion como si fuera un postman con la ruta, todo con el resultado esperado");
        MvcResult result = mockMvc.perform(get("/api/v1/users/getAllUsers"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("ER001"))
                .andExpect(jsonPath("$.status").value("No se encontraron usuarios"))
                .andExpect(content().json(objectMapper.writeValueAsString(dto)))
                .andReturn();
        log.info("Resultado no se encontraron usuarios: " + result.getResponse().getContentAsString());
    }

    @Test
    @DisplayName("Actualizar datos de usuario")
    public void DadoElServicioActualizaUsuario_SiRecibeLosParametrosNecesarios_ActualizaLosDatosDeUsuario() throws Exception {
        /* Pruebas para Happy Path - UserControllerTest - ActualizarContraseniaUserController */
        log.info("Se inicializan los parametros necesarios");
        Integer id = 1;

        User user = new User();
        user.setId(1);
        user.setName("Edson");
        user.setUserName("Garcia");
        user.setEmail("mail@ejemplo.com");

        UserDTO userDto = new UserDTO();
        userDto.setId(1);
        userDto.setName("ALfredo");
        userDto.setUserName("Garcia");
        userDto.setEmail("mail@ejemplo1.com");

        log.info("Se mockea el componente que responderá con el valor esperado");
        Mockito.when(userDAO.updateUser(id, userDto)).thenReturn(user);

        log.info("Se cerea la respuesta general con sus datos esperados");
        ResponseDTO dto = new ResponseDTO();
        userDAO.updateUser(id, userDto);
        dto.setCode("OK000");
        dto.setStatus("Datos actualizados");
        dto.setResultado(user);

        log.info("Se mockea el servicio que respondera de la manera esperada con la respuesta general");
        Mockito.when(userService.updateUser(id, userDto)).thenReturn(ResponseEntity.ok(dto));


        log.info("Se crea la peticion simulando postman con la ruta y los parametros de entrada, todo con el resultado esperado");
        MvcResult result = mockMvc.perform(put("/api/v1/users/updateUser/{id}", id)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(userDto)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value("OK000"))
                .andExpect(jsonPath("$.status").value("Datos Actualizados"))
                .andExpect(content().json(objectMapper.writeValueAsString(dto)))
                .andReturn();

        log.info("Resultado cambio de contrasenia: " + result.getResponse().getContentAsString());
    }

    @Test
    @DisplayName("Edge Case - ActualizarContraseniaController - ValidaParametroNuloOVacio")
    public void DadoElServicioActualizaUsuario_SiRecibeLosParametrosVacios_RegresaBadRequest() throws Exception {
        Integer id = null;

        log.info("Se implementan los parametros de entrada a un mapa");
        LinkedMultiValueMap<String, String> requestParams = new LinkedMultiValueMap<>();
        requestParams.add("id", null);
        requestParams.add("name", null);
        requestParams.add("userName", null);
        requestParams.add("email", null);

        log.info("Se estructura la respuesta general mala esperada");
        ResponseDTO dto = new ResponseDTO();
        dto.setCode("ER001");
        dto.setStatus("Los parametros son requeridos");

        log.info("Se mockea el servicio que repondera con la respuesta mala esperada");
        Mockito.when(userService.updateUser(null, null)).thenReturn(new ResponseEntity<>(dto, HttpStatus.BAD_REQUEST));

        log.info("Se arma la peticion como si fuera un postman con la ruta y los parametros de entrada, todo con el resultado esperado");
        MvcResult result = mockMvc.perform(put("/api/v1/users/updateUser/{id}", id )
                        .params(requestParams))
                .andExpect(status().isBadRequest())
                .andReturn();

        log.info("MvcResult result actualizar datos usuario: "+result.getResponse().getContentAsString());
    }

    @Test
    @DisplayName("Edge Case - ActualizaDatosUSuarioController - UsuarioNoExistente")
    public void DadoElServicioActualizaContrasenia_SiRecibeLosParametrosVacios_RegresaRespuestaGeneralErroneaControlada() throws Exception {
        log.info("Se inicializan los parametros simulados no existentes");
        Integer idNoExiste = null;
        UserDTO userDto = new UserDTO();
        userDto.setId(14);
        userDto.setName("ALfredo");
        userDto.setUserName("Garcia");
        userDto.setEmail("mail@ejemplo1.com");

        User user = new User();
        user.setId(13);
        user.setName("Edson");
        user.setUserName("Garcia");
        user.setEmail("mail@ejemplo.com");

        log.info("Se estructura la respuesta general mala esperada");
        ResponseDTO dto = new ResponseDTO();
        dto.setCode("ER001");
        dto.setStatus("Parametros requeridos");

        log.info("se mockea el servicio que devolverá la respuesta mala esperada");
        Mockito.when(userService.updateUser(null, null)).thenReturn(new ResponseEntity<>(dto, HttpStatus.BAD_REQUEST));

        log.info("Se arma la peticion como si fuera un postman con la ruta y los parametros de entrada, todo con el resultado esperado");
        MvcResult result = mockMvc.perform(put("/api/v1/users/updateUser/{id}", "")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(userDto)))
                .andExpect(status().isBadRequest())
                .andReturn();

        log.info("MvcResult usuario y/o contrasenia no valida: "+result.getResponse().getContentAsString());
    }

    @Test
    @DisplayName("Busca Usuario por Id")
    public void DadoElServicioObtenerUsuarioPorId_AlIngresarElIdDelUsuario_BuscaEnLaBDLaExistencia() throws Exception {
        /* Pruebas para Happy Path - UserControllerTest - BuscaUsuarioPorIdUserController */
        log.info("Se crea el usuario esperado");
        User user = new User();
        user.setId(1);
        user.setName("Edson");
        user.setUserName("Garcia");
        user.setEmail("mail@ejemplo.com");

        log.info("Se mockea el componente que dara como respuesta el usuario anterior");
        Mockito.when(userDAO.findById(Mockito.anyInt())).thenReturn(user);

        log.info("Se estructura la respuesta general esperada");
        ResponseDTO dto = new ResponseDTO();
        dto.setCode("OK000");
        dto.setStatus("Usuario encontrado");
        dto.setResultado(userDAO.findById(1));

        log.info("Se mockea el servicio que respondera con la respuesta general correcta");
        Mockito.when(userService.findById(Mockito.anyInt())).thenReturn(ResponseEntity.ok(dto));

        log.info("Se crea la peticion simulando postman con la ruta y el parametros de entrada, todo con el resultado esperado");
        MvcResult result = mockMvc.perform(get("/api/v1/users/findByID/{id}", 1))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value("OK000"))
                .andExpect(jsonPath("$.status").value("Usuario encontrado"))
                .andExpect(content().json(objectMapper.writeValueAsString(dto)))
                .andReturn();

        log.info("MvcResult result encontrar usuario por id: " + result.getResponse().getContentAsString());
    }

    @Test
    @DisplayName("Edge Case - BuscaUsuarioporIdController - ValidaParametroNuloOVacio")
    public void DadoElServicioObtenerUsuarioPorId_AlIngresarElIdDelUsuarioNuloOVacio_RegresaNotFoundElServicio() throws Exception {
        log.info("Se inicializa el parametro del servicio, este con un valor nulo o vacio");
        // Este servicio responde con NotFound, ya que de inicio no completa la ruta por falta de la pathVariable al ser nulo o ""
        String idUsuario = null;

        log.info("Se crea la peticion simulando postman con la ruta y el parametro de entrada, todo con el estatus esperado");
        mockMvc.perform(get("/api/v1/users/findByID/{id}", idUsuario))
                .andExpect(status().isNotFound())
                .andReturn();
    }

    @Test
    @DisplayName("Edge Case - BuscaUsuarioporIdController - RespuestaErroneaControlada")
    public void DadoElServicioObtenerUsuarioPorId_AlIngresarElIdDelUsuarioNoExistente_RegresaErrorGeneralControlado() throws Exception {
        Integer idNoExistenteEjemplo = 563;

        log.info("Se estructura la respuesta general con los datos esperados");
        ResponseDTO dto = new ResponseDTO();
        dto.setCode("ER001");
        dto.setStatus("No existe este usuario con este id: "+ idNoExistenteEjemplo);

        log.info("Se mockea el servicio que devolvera la respuesta esperada");
        Mockito.when(userService.findById(idNoExistenteEjemplo)).thenReturn(new ResponseEntity<>(dto, HttpStatus.BAD_REQUEST));

        log.info("Se crea la peticion simulando postman con la ruta y el parametro de entrada, todo con el resultado esperado");
        MvcResult result = mockMvc.perform(get("/api/v1/users/findByID/{id}", idNoExistenteEjemplo))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("ER001"))
                .andExpect(jsonPath("$.status").value("No existe este usuario con este id: "+ idNoExistenteEjemplo))
                .andExpect(content().json(objectMapper.writeValueAsString(dto)))
                .andReturn();

        log.info("Resultado de buscar usuario por id: " + result.getResponse().getContentAsString());
    }

    /* Prueba unitaria de cada endpoint de la API - Eliminar Usuario por Id */
    @Test
    @DisplayName("Eliminar Usuario por Id")
    public void DadoElServicioEliminarUsuarioPorId_AlIngresarElIdDelUsuario_BuscaYEliminaDeLaBD() throws Exception {
        /* Pruebas para Happy Path - UserControllerTest - EliminaUsuarioPorIdUserController */
        log.info("Se mockea el componente que devolvera el resultado esperado");
        Mockito.when(userDAO.deleteUser(Mockito.anyInt())).thenReturn(1L);

        log.info("Se estructura la respuesta general esperada, con sus datos");
        ResponseDTO dto = new ResponseDTO();
        dto.setCode("OK000");
        dto.setStatus("Usuario eliminado");
        dto.setResultado(userDAO.deleteUser(1));

        log.info("Se mockea el servicio que respondera con la respuesta general correcta");
        Mockito.when(userService.deleteUser(Mockito.anyInt())).thenReturn(ResponseEntity.ok(dto));

        log.info("Se crea la peticion simulando postman con la ruta y el parametro de entrada, todo con el resultado esperado");
        MvcResult result = mockMvc.perform(delete("/api/v1/users/deleteUser/{id}", 1))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value("OK000"))
                .andExpect(jsonPath("$.status").value("Usuario eliminado"))
                .andExpect(content().json(objectMapper.writeValueAsString(dto)))
                .andReturn();

        log.info("Resultado de eliminar usuario por id: " + result.getResponse().getContentAsString());
    }

    @Test
    @DisplayName("Edge Case - EliminaUsuarioPorIdController - ValidaParametroNuloOVacio")
    public void DadoElServicioEliminarUsuarioPorId_AlIngresarUnIdDeUsuarioNuloOVacio_DevuelveNotFoundDelServicio() throws Exception {
        String idUsuario = null;

        log.info("Se crea la peticion simulando postman con la ruta y el parametro de entrada, todo con el status esperado");
        mockMvc.perform(delete("/api/v1/users/deleteUser/{id}", idUsuario))
                .andExpect(status().isNotFound())
                .andReturn();
    }

    @Test
    @DisplayName("Edge Case - EliminaUsuarioPorIdController - RespuestaErroneaControlada")
    public void DadoElServicioEliminarUsuarioPorId_AlIngresarUnIdDeUsuarioNoExistente_DevuelveRespuestaControlada() throws Exception {
        log.info("Se inicializa el parametro esperado");
        Integer idNoExistenteEjemplo = 123;

        log.info("Se estructuira la respuesta general con sus valores esperados");
        ResponseDTO dto = new ResponseDTO();
        dto.setCode("ER001");
        dto.setStatus("No existe este usuario con este id: "+idNoExistenteEjemplo);

        log.info("Se mockea el servicio que respondera con la respuesta mala esperada");
        Mockito.when(userService.deleteUser(idNoExistenteEjemplo)).thenReturn(new ResponseEntity<>(dto, HttpStatus.BAD_REQUEST));

        log.info("Se arma la peticion como si fuera un postman con la ruta y el parametro de entrada, todo con el status esperado");
        MvcResult result = mockMvc.perform(delete("/api/v1/users/deleteUser/{id}", idNoExistenteEjemplo))
                .andExpect(status().isBadRequest())
                .andReturn();

        log.info("Resultado de eliminar usuario por id: " + result.getResponse().getContentAsString());
    }

    @Test
    @DisplayName("Consumo de api publica por restTemplate")
    public void DadoElServicioConsumirApiPublica_AlIngresar_ConsumeElApiNomasXD() throws Exception {
        /* Pruebas para Happy Path  */
        log.info("Se crea la respuesta general esperada con sus datos necesarios");
        ResponseDTO dto = new ResponseDTO();
        dto.setCode("OK000");
        dto.setStatus("Api consumida");

        log.info("Se mockea el servicio que responde con el valor esperado");
        Mockito.when(userService.getUserApiPublica(Mockito.anyString())).thenReturn(ResponseEntity.ok(dto));

        log.info("Se crea la peticion simulando un postman con la ruta, todo con el resultado esperado");
        MvcResult result = mockMvc.perform(get("/api/v1/users/apipublica"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value("OK000"))
                .andExpect(jsonPath("$.status").value("Api consumida"))
                .andExpect(content().json(objectMapper.writeValueAsString(dto)))
                .andReturn();

        log.info("Resultado de api consumida: " + result.getResponse().getContentAsString());
    }

    @Test
    @DisplayName("Edge Case - ConsumeApiPublicaController - RespuestaErroneaControlada")
    public void DadoElServicioConsumirApiPublica_AlIngresar_ConsumeElApiNomasXD1() throws Exception {
        log.info("Se crea la respuesta general esperada con sus datos necesarios");
        ResponseDTO dto = new ResponseDTO();
        dto.setCode("ER001");
        dto.setStatus("Fallo al consumir la api publica");
        ErrorDTO errorDTO = new ErrorDTO("ER001", "Fallo al consumir la api publica");
        dto.setErrors(errorDTO);

        log.info("Se mockea el servicio que responde con la respuesta general mala esperada");
        Mockito.when(userService.getUserApiPublica(Mockito.anyString())).thenReturn(new ResponseEntity<>(dto, HttpStatus.BAD_REQUEST));

        log.info("Se arma la peticion como si fuera un postman con la ruta, todo con el resultado esperado");
        MvcResult result = mockMvc.perform(get("/api/v1/users/apipublica"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("ER001"))
                .andExpect(jsonPath("$.status").value("Fallo al consumir la api publica"))
                .andExpect(content().json(objectMapper.writeValueAsString(dto)))
                .andReturn();

        log.info("Resultado de fallo al consumir api publica: " + result.getResponse().getContentAsString());
    }
}
