package com.wizeline.cursojava.daoTest;

import com.mongodb.client.result.DeleteResult;
import com.wizeline.cursojava.dto.UserDTO;
import com.wizeline.cursojava.model.User;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Component
public class UserDAO {

    @Autowired
    private MongoTemplate mongoTemplate;

    public List<User> getUsers() {
        List<User> usuarios = mongoTemplate.findAll(User.class);
        return usuarios;
    }

    public User saveUser(User user) {
        User userResult = mongoTemplate.save(user);
        return userResult;

    }

    public User updateUser(Integer id, UserDTO userDto) {
        User user = findById(id);
        BeanUtils.copyProperties(userDto, user);
        return mongoTemplate.save(user);
    }

    public Long deleteUser(Integer id) {
        User user = findById(id);
        DeleteResult deleteResult = mongoTemplate.remove(user);
        return deleteResult.getDeletedCount();
    }

    public User findById(Integer id) {
        return mongoTemplate.findById(id, User.class);
    }

}
