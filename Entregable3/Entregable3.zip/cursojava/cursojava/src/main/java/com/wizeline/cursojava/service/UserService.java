package com.wizeline.cursojava.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.wizeline.cursojava.dto.ResponseDTO;
import com.wizeline.cursojava.dto.UserDTO;
import com.wizeline.cursojava.model.User;


public interface UserService {

	ResponseEntity<ResponseDTO> getUsers();

	ResponseEntity<ResponseDTO> findById(Integer id);
	
	ResponseEntity<ResponseDTO> saveUser(UserDTO user);

	ResponseEntity<ResponseDTO> updateUser(Integer id, UserDTO use);

	ResponseEntity<ResponseDTO> deleteUser(Integer id);

	ResponseEntity<ResponseDTO> getUserApiPublica(String basePath);

	
	

}
