package com.wizeline.cursojava.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wizeline.cursojava.dto.UserDTO;
import com.wizeline.cursojava.service.UserService;

@RestController
@RequestMapping("/api/v1/users")
public class UserController {
	
	@Autowired
	private UserService service;

	@GetMapping("/apipublica")
	public ResponseEntity<?> getAllUsersApiPublic() {
		String basePaht = "https://6341b62a16ffb7e275d6a8b9.mockapi.io/api/v1/users";
		return service.getUserApiPublica(basePaht);
	}
	
	@GetMapping("/getAllUsers")
	public ResponseEntity<?> getAll() {
		return service.getUsers();
	}
	
	@PostMapping("/saveUser")
	public ResponseEntity<?> saveUser(@RequestBody UserDTO user) {
		return service.saveUser(user);
		
	}
	
	@GetMapping("/findByID/{id}")
	public ResponseEntity<?> finById(@PathVariable Integer id) {
		return service.findById(id);
	}
	
	@PutMapping("/updateUser/{id}")
	public ResponseEntity<?> updateUser(@PathVariable Integer id, @RequestBody UserDTO use) {

		return service.updateUser(id, use);
	}
	
	@DeleteMapping("/deleteUser/{id}")
	public ResponseEntity<?> deleteUser(@PathVariable Integer id) {
		return service.deleteUser(id);
	}

}
