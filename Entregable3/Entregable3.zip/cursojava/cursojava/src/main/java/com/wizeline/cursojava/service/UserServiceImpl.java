package com.wizeline.cursojava.service;

import java.util.List;

import com.wizeline.cursojava.daoTest.UserDAO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.wizeline.cursojava.dto.ResponseDTO;
import com.wizeline.cursojava.dto.UserDTO;
import com.wizeline.cursojava.model.User;
import com.wizeline.cursojava.dto.ErrorDTO;

@Service
public class UserServiceImpl implements UserService {

	private static final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);
	
	@Autowired
	private UserDAO userDAO;

	@Override
	public ResponseEntity<ResponseDTO> getUserApiPublica(String basePath) {
		ResponseDTO responseDTO = new ResponseDTO();
		RestTemplate restTemplate = new RestTemplate();
		UserDTO[] object = restTemplate.getForObject(basePath, UserDTO[].class);

		if (object == null) {
			log.info("No se pudo consumir la api publica");
			ErrorDTO errorDTO = new ErrorDTO("ER001", "Fallo al consumir la api publica");
			responseDTO.setErrors(errorDTO);

			return new ResponseEntity<>(responseDTO, HttpStatus.BAD_REQUEST);
		}
		responseDTO.setCode("OK000");
		responseDTO.setStatus("Api consumida");
		responseDTO.setResultado(object);
		return ResponseEntity.ok(responseDTO);

	}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	@Override
	public ResponseEntity<ResponseDTO> getUsers() {
		ResponseDTO responseDTO = new ResponseDTO();

		List<User> users = userDAO.getUsers();
		if ( users.size() <= 0) {

			log.info("No se encontraron usuarios");
			ErrorDTO errorDTO = new ErrorDTO("ER001", "No se encontraron usuarios");
			responseDTO.setErrors(errorDTO);
		}

		responseDTO.setCode("OK000");
		responseDTO.setStatus("Usuarios encontrados");
		responseDTO.setResultado(users);

		return new ResponseEntity<>(responseDTO, HttpStatus.BAD_REQUEST);
	}

	@Override
	public ResponseEntity<ResponseDTO> saveUser(UserDTO userDto) {
		ResponseDTO response = new ResponseDTO();
		User userNew = new User();
		BeanUtils.copyProperties(userDto, userNew);
		userNew = userDAO.saveUser(userNew);
		if (userNew == null) {
			log.info("No se inserto el usuario");
			ErrorDTO errorDTO = new ErrorDTO("ER001", "Usuario no creado");
			response.setErrors(errorDTO);
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}
		response.setCode("OK000");
		response.setStatus("Usuario Creado");
		return ResponseEntity.ok(response);

	}

	@Override
	public ResponseEntity<ResponseDTO> updateUser(Integer id, UserDTO userDto) {
		ResponseDTO responseDTO = new ResponseDTO();
		User userNew = userDAO.updateUser(id, userDto);
		if (userNew == null){
			log.info("No se actualizo el usuario");
			ErrorDTO errorDTO = new ErrorDTO("ER001", "No se actualizo el usuarios con id: "+ id);
			responseDTO.setErrors(errorDTO);

			return new ResponseEntity<>(responseDTO, HttpStatus.BAD_REQUEST);
		}
		responseDTO.setCode("OK000");
		responseDTO.setStatus("Datos de usuario actualizados");
		responseDTO.setResultado("Usuarios actulizados: " + userNew.getName());

		return ResponseEntity.ok(responseDTO);
	}

	@Override
	public ResponseEntity<ResponseDTO> deleteUser(Integer id) {
		ResponseDTO responseDTO = new ResponseDTO();
		 long usuariosEliminados = userDAO.deleteUser(id);
		 if (usuariosEliminados <= 0){
			 log.info("El usuario no pudo ser eliminado");
			 ErrorDTO errorDTO = new ErrorDTO("ER001", "Usuario no eliminado: "+ id);
			 responseDTO.setErrors(errorDTO);

			 return new ResponseEntity<>(responseDTO, HttpStatus.BAD_REQUEST);
		 }
		responseDTO.setCode("OK000");
		responseDTO.setStatus("Usuario borrado!");
		responseDTO.setResultado("Total eliminado: "+ usuariosEliminados);

		return ResponseEntity.ok(responseDTO);



	}

	@Override
	public ResponseEntity<ResponseDTO> findById(Integer id) {
		ResponseDTO responseDTO = new ResponseDTO();

         User user = userDAO.findById(id);

		 if (user != null) {
			 log.info("No se encontró el usuario");
			 ErrorDTO errorDTO = new ErrorDTO("ER001", "Usuario no econtrado");

			 responseDTO.setErrors(errorDTO);

			 return new ResponseEntity<>(responseDTO, HttpStatus.BAD_REQUEST);
		 }
		responseDTO.setCode("OK000");
		responseDTO.setStatus("Contrasenia de usuario actualizado");
		responseDTO.setResultado(user);

		return ResponseEntity.ok(responseDTO);
	}

}
