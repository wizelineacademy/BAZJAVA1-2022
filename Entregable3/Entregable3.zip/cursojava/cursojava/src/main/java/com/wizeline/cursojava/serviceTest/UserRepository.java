package com.wizeline.cursojava.serviceTest;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.wizeline.cursojava.dto.UserDTO;

public interface UserRepository extends MongoRepository<UserDTO, Integer>{

}
