package com.wizeline.cursojava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CursojavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CursojavaApplication.class, args);
	}

}
